"""Campaign runtime adapter tests."""
