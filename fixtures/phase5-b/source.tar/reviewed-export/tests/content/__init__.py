"""Content compiler tests."""
