"""Asset compiler tests."""
