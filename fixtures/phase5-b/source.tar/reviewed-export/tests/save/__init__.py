"""Save-journal tests."""
